#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_

#define CONF_SFD_TIMESTAMPS	1

#endif
